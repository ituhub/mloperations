# ML Model Monitoring Platform - Data Upload Module
# =============================================================================
# Supports: CSV, Excel, JSON, Parquet file uploads
# Data types: Models, Metrics, Predictions, Reference Data
# =============================================================================

import streamlit as st
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
from dataclasses import dataclass
import json
import io
import os
from pathlib import Path

# Optional imports
try:
    import openpyxl
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

try:
    import pyarrow.parquet as pq
    PARQUET_AVAILABLE = True
except ImportError:
    PARQUET_AVAILABLE = False


# =============================================================================
# DATA SCHEMAS - Expected column formats
# =============================================================================

@dataclass
class DataSchema:
    """Schema definition for data validation"""
    required_columns: List[str]
    optional_columns: List[str]
    column_types: Dict[str, str]
    description: str
    example_data: Dict[str, List]


# Define schemas for different data types
SCHEMAS = {
    'models': DataSchema(
        required_columns=['model_id', 'name', 'type'],
        optional_columns=['framework', 'version', 'status', 'deployed_at', 'description',
                         'predictions_today', 'avg_latency_ms', 'accuracy', 'mae'],
        column_types={
            'model_id': 'string',
            'name': 'string',
            'type': 'string (Classification/Regression)',
            'framework': 'string',
            'version': 'string',
            'status': 'string (healthy/warning/critical)',
            'deployed_at': 'datetime',
            'predictions_today': 'integer',
            'avg_latency_ms': 'float',
            'accuracy': 'float (0-1)',
            'mae': 'float'
        },
        description='Model registry information',
        example_data={
            'model_id': ['model_001', 'model_002'],
            'name': ['Churn Predictor', 'Revenue Forecast'],
            'type': ['Classification', 'Regression'],
            'framework': ['XGBoost', 'LightGBM'],
            'version': ['v1.0', 'v2.1'],
            'status': ['healthy', 'warning']
        }
    ),
    
    'metrics': DataSchema(
        required_columns=['model_id', 'timestamp', 'metric_name', 'metric_value'],
        optional_columns=['batch_size', 'metadata'],
        column_types={
            'model_id': 'string',
            'timestamp': 'datetime',
            'metric_name': 'string (mae/rmse/accuracy/latency_ms/etc)',
            'metric_value': 'float',
            'batch_size': 'integer'
        },
        description='Time-series performance metrics',
        example_data={
            'model_id': ['model_001', 'model_001', 'model_001'],
            'timestamp': ['2025-01-01 10:00', '2025-01-01 10:10', '2025-01-01 10:20'],
            'metric_name': ['mae', 'mae', 'mae'],
            'metric_value': [0.05, 0.052, 0.048]
        }
    ),
    
    'predictions': DataSchema(
        required_columns=['model_id', 'timestamp', 'prediction'],
        optional_columns=['prediction_id', 'actual', 'latency_ms', 'is_anomaly', 
                         'anomaly_score', 'confidence'] + [f'feature_{i}' for i in range(20)],
        column_types={
            'model_id': 'string',
            'timestamp': 'datetime',
            'prediction': 'float',
            'actual': 'float (ground truth)',
            'latency_ms': 'float',
            'feature_*': 'float (input features)'
        },
        description='Individual prediction logs with features',
        example_data={
            'model_id': ['model_001', 'model_001'],
            'timestamp': ['2025-01-01 10:00:01', '2025-01-01 10:00:02'],
            'prediction': [0.85, 0.23],
            'actual': [1.0, 0.0],
            'feature_1': [35, 42],
            'feature_2': [75000, 52000]
        }
    ),
    
    'reference_data': DataSchema(
        required_columns=['model_id', 'feature_name'],
        optional_columns=['mean_value', 'std_value', 'min_value', 'max_value',
                         'percentile_25', 'percentile_50', 'percentile_75'],
        column_types={
            'model_id': 'string',
            'feature_name': 'string',
            'mean_value': 'float',
            'std_value': 'float',
            'min_value': 'float',
            'max_value': 'float'
        },
        description='Training data distribution statistics for drift detection',
        example_data={
            'model_id': ['model_001', 'model_001'],
            'feature_name': ['age', 'income'],
            'mean_value': [35.5, 65000],
            'std_value': [12.3, 25000],
            'min_value': [18, 20000],
            'max_value': [75, 200000]
        }
    ),
    
    'alerts': DataSchema(
        required_columns=['model_id', 'severity', 'title', 'message'],
        optional_columns=['alert_id', 'category', 'timestamp', 'status', 'recommendations'],
        column_types={
            'model_id': 'string',
            'severity': 'string (info/low/medium/high/critical)',
            'category': 'string (drift/performance/latency/error)',
            'title': 'string',
            'message': 'string',
            'timestamp': 'datetime',
            'status': 'string (active/acknowledged/resolved)'
        },
        description='Alert definitions',
        example_data={
            'model_id': ['model_001'],
            'severity': ['high'],
            'category': ['drift'],
            'title': ['Data Drift Detected'],
            'message': ['Feature income shows significant drift (PSI: 0.25)']
        }
    ),
    
    'raw_features': DataSchema(
        required_columns=[],  # Any columns accepted
        optional_columns=['target', 'prediction', 'timestamp', 'model_id'],
        column_types={
            '*': 'Any numeric or categorical features'
        },
        description='Raw feature data for drift analysis (auto-detected columns)',
        example_data={
            'age': [25, 35, 45],
            'income': [50000, 75000, 100000],
            'tenure': [12, 24, 36],
            'target': [0, 1, 1]
        }
    )
}


# =============================================================================
# FILE PARSING FUNCTIONS
# =============================================================================

def read_uploaded_file(uploaded_file, file_type: str = None) -> Tuple[Optional[pd.DataFrame], Optional[str]]:
    """
    Read uploaded file and return DataFrame
    
    Args:
        uploaded_file: Streamlit uploaded file object
        file_type: Override file type detection
        
    Returns:
        Tuple of (DataFrame, error_message)
    """
    if uploaded_file is None:
        return None, "No file uploaded"
    
    try:
        file_name = uploaded_file.name.lower()
        
        # Determine file type
        if file_type:
            ext = file_type
        elif file_name.endswith('.csv'):
            ext = 'csv'
        elif file_name.endswith(('.xlsx', '.xls')):
            ext = 'excel'
        elif file_name.endswith('.json'):
            ext = 'json'
        elif file_name.endswith('.parquet'):
            ext = 'parquet'
        else:
            return None, f"Unsupported file format: {file_name}"
        
        # Read file
        if ext == 'csv':
            # Try different encodings
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    uploaded_file.seek(0)
                    df = pd.read_csv(uploaded_file, encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
            else:
                return None, "Could not decode CSV file"
        
        elif ext == 'excel':
            if not EXCEL_AVAILABLE:
                return None, "Excel support not available. Install openpyxl: pip install openpyxl"
            uploaded_file.seek(0)
            df = pd.read_excel(uploaded_file)
        
        elif ext == 'json':
            uploaded_file.seek(0)
            content = uploaded_file.read().decode('utf-8')
            data = json.loads(content)
            
            # Handle different JSON structures
            if isinstance(data, list):
                df = pd.DataFrame(data)
            elif isinstance(data, dict):
                if 'data' in data:
                    df = pd.DataFrame(data['data'])
                else:
                    df = pd.DataFrame([data])
            else:
                return None, "Invalid JSON structure"
        
        elif ext == 'parquet':
            if not PARQUET_AVAILABLE:
                return None, "Parquet support not available. Install pyarrow: pip install pyarrow"
            uploaded_file.seek(0)
            df = pd.read_parquet(uploaded_file)
        
        else:
            return None, f"Unsupported format: {ext}"
        
        return df, None
        
    except Exception as e:
        return None, f"Error reading file: {str(e)}"


def validate_dataframe(df: pd.DataFrame, data_type: str) -> Tuple[bool, List[str], List[str]]:
    """
    Validate DataFrame against expected schema
    
    Returns:
        Tuple of (is_valid, errors, warnings)
    """
    errors = []
    warnings = []
    
    if data_type not in SCHEMAS:
        return True, [], ["Unknown data type - skipping validation"]
    
    schema = SCHEMAS[data_type]
    
    # Check required columns
    missing_required = [col for col in schema.required_columns if col not in df.columns]
    if missing_required:
        errors.append(f"Missing required columns: {missing_required}")
    
    # Check for empty DataFrame
    if len(df) == 0:
        errors.append("DataFrame is empty")
    
    # Check data types
    for col in df.columns:
        if col in schema.required_columns or col in schema.optional_columns:
            # Basic type checking
            if 'datetime' in schema.column_types.get(col, ''):
                try:
                    pd.to_datetime(df[col])
                except:
                    warnings.append(f"Column '{col}' may not be a valid datetime")
            
            elif 'float' in schema.column_types.get(col, '') or 'integer' in schema.column_types.get(col, ''):
                if not pd.api.types.is_numeric_dtype(df[col]):
                    warnings.append(f"Column '{col}' should be numeric")
    
    is_valid = len(errors) == 0
    return is_valid, errors, warnings


def preprocess_dataframe(df: pd.DataFrame, data_type: str) -> pd.DataFrame:
    """
    Preprocess DataFrame - convert types, handle missing values
    """
    df = df.copy()
    
    # Convert timestamp columns
    timestamp_cols = ['timestamp', 'deployed_at', 'created_at', 'updated_at']
    for col in timestamp_cols:
        if col in df.columns:
            try:
                df[col] = pd.to_datetime(df[col])
            except:
                pass
    
    # Convert numeric columns
    if data_type == 'metrics':
        if 'metric_value' in df.columns:
            df['metric_value'] = pd.to_numeric(df['metric_value'], errors='coerce')
    
    elif data_type == 'predictions':
        if 'prediction' in df.columns:
            df['prediction'] = pd.to_numeric(df['prediction'], errors='coerce')
        if 'actual' in df.columns:
            df['actual'] = pd.to_numeric(df['actual'], errors='coerce')
        if 'latency_ms' in df.columns:
            df['latency_ms'] = pd.to_numeric(df['latency_ms'], errors='coerce')
    
    # Fill missing status with default
    if 'status' in df.columns:
        df['status'] = df['status'].fillna('healthy')
    
    return df


# =============================================================================
# DATA STORAGE CLASS
# =============================================================================

class UploadedDataStore:
    """
    In-memory store for uploaded data.
    Persists data during the Streamlit session.
    """
    
    def __init__(self):
        self.models: Dict[str, Dict] = {}
        self.metrics: pd.DataFrame = pd.DataFrame()
        self.predictions: pd.DataFrame = pd.DataFrame()
        self.reference_data: Dict[str, pd.DataFrame] = {}
        self.alerts: List[Dict] = []
        self.raw_features: Dict[str, pd.DataFrame] = {}
        self.upload_history: List[Dict] = []
    
    def add_models(self, df: pd.DataFrame):
        """Add models from DataFrame"""
        for _, row in df.iterrows():
            model_id = row['model_id']
            self.models[model_id] = row.to_dict()
        
        self._log_upload('models', len(df))
    
    def add_metrics(self, df: pd.DataFrame):
        """Add metrics from DataFrame"""
        if self.metrics.empty:
            self.metrics = df
        else:
            self.metrics = pd.concat([self.metrics, df], ignore_index=True)
        
        # Sort by timestamp
        if 'timestamp' in self.metrics.columns:
            self.metrics = self.metrics.sort_values('timestamp')
        
        self._log_upload('metrics', len(df))
    
    def add_predictions(self, df: pd.DataFrame):
        """Add predictions from DataFrame"""
        if self.predictions.empty:
            self.predictions = df
        else:
            self.predictions = pd.concat([self.predictions, df], ignore_index=True)
        
        if 'timestamp' in self.predictions.columns:
            self.predictions = self.predictions.sort_values('timestamp')
        
        self._log_upload('predictions', len(df))
    
    def add_reference_data(self, model_id: str, df: pd.DataFrame):
        """Add reference data for a model"""
        self.reference_data[model_id] = df
        self._log_upload('reference_data', len(df))
    
    def add_raw_features(self, model_id: str, df: pd.DataFrame):
        """Add raw feature data for drift analysis"""
        self.raw_features[model_id] = df
        self._log_upload('raw_features', len(df))
    
    def add_alerts(self, df: pd.DataFrame):
        """Add alerts from DataFrame"""
        for _, row in df.iterrows():
            alert = row.to_dict()
            if 'timestamp' not in alert or pd.isna(alert['timestamp']):
                alert['timestamp'] = datetime.now()
            if 'status' not in alert:
                alert['status'] = 'active'
            self.alerts.append(alert)
        
        self._log_upload('alerts', len(df))
    
    def _log_upload(self, data_type: str, count: int):
        """Log upload to history"""
        self.upload_history.append({
            'timestamp': datetime.now(),
            'data_type': data_type,
            'records': count
        })
    
    def get_models(self) -> Dict[str, Dict]:
        """Get all models"""
        if not self.models:
            # Return demo models if no uploads
            return self._get_demo_models()
        return self.models
    
    def get_metrics(self, model_id: str, hours: int = 24) -> pd.DataFrame:
        """Get metrics for a model"""
        if self.metrics.empty:
            return self._generate_demo_metrics(model_id, hours)
        
        df = self.metrics[self.metrics['model_id'] == model_id].copy()
        
        if 'timestamp' in df.columns:
            cutoff = datetime.now() - timedelta(hours=hours)
            df = df[df['timestamp'] > cutoff]
        
        return df
    
    def get_predictions(self, model_id: str, limit: int = 1000) -> pd.DataFrame:
        """Get predictions for a model"""
        if self.predictions.empty:
            return pd.DataFrame()
        
        df = self.predictions[self.predictions['model_id'] == model_id].copy()
        return df.tail(limit)
    
    def get_reference_data(self, model_id: str) -> pd.DataFrame:
        """Get reference data for a model"""
        return self.reference_data.get(model_id, pd.DataFrame())
    
    def get_raw_features(self, model_id: str) -> pd.DataFrame:
        """Get raw features for drift analysis"""
        return self.raw_features.get(model_id, pd.DataFrame())
    
    def get_alerts(self, model_id: str = None) -> List[Dict]:
        """Get alerts"""
        if not self.alerts:
            return self._get_demo_alerts(model_id)
        
        if model_id:
            return [a for a in self.alerts if a.get('model_id') == model_id]
        return self.alerts
    
    def clear_all(self):
        """Clear all uploaded data"""
        self.__init__()
    
    # Demo data fallbacks
    def _get_demo_models(self) -> Dict[str, Dict]:
        return {
            'model_001': {
                'model_id': 'model_001',
                'name': 'Customer Churn Predictor',
                'type': 'Classification',
                'framework': 'XGBoost',
                'version': 'v2.3.1',
                'deployed_at': datetime.now() - timedelta(days=45),
                'status': 'healthy',
                'predictions_today': 15420,
                'avg_latency_ms': 23.5,
                'accuracy': 0.94
            },
            'model_002': {
                'model_id': 'model_002',
                'name': 'Revenue Forecaster',
                'type': 'Regression',
                'framework': 'LightGBM',
                'version': 'v1.8.0',
                'deployed_at': datetime.now() - timedelta(days=120),
                'status': 'warning',
                'predictions_today': 8930,
                'avg_latency_ms': 45.2,
                'mae': 0.0234
            }
        }
    
    def _generate_demo_metrics(self, model_id: str, hours: int) -> pd.DataFrame:
        np.random.seed(hash(model_id) % 2**32)
        
        timestamps = pd.date_range(
            end=datetime.now(),
            periods=hours * 6,
            freq='10min'
        )
        
        return pd.DataFrame({
            'timestamp': timestamps,
            'mae': 0.05 + np.random.normal(0, 0.005, len(timestamps)),
            'rmse': 0.06 + np.random.normal(0, 0.008, len(timestamps)),
            'accuracy': np.clip(0.92 + np.random.normal(0, 0.01, len(timestamps)), 0.8, 1.0),
            'latency_ms': 20 + np.random.exponential(10, len(timestamps)),
            'predictions_count': np.random.poisson(100, len(timestamps))
        })
    
    def _get_demo_alerts(self, model_id: str = None) -> List[Dict]:
        alerts = [
            {
                'alert_id': 'alert_001',
                'model_id': 'model_002',
                'severity': 'medium',
                'category': 'drift',
                'title': 'Minor Data Drift Detected',
                'message': 'Upload your own data to see real alerts',
                'timestamp': datetime.now() - timedelta(hours=2),
                'status': 'active'
            }
        ]
        
        if model_id:
            return [a for a in alerts if a.get('model_id') == model_id]
        return alerts


# =============================================================================
# STREAMLIT UI COMPONENTS
# =============================================================================

def render_upload_section(data_store: UploadedDataStore):
    """Render the data upload section in Streamlit"""
    
    st.markdown("### 📤 Upload Your Data")
    
    st.markdown("""
    <div style="background: #EEF2FF; border-radius: 12px; padding: 1.5rem; margin-bottom: 1.5rem;">
        <h4 style="margin: 0 0 0.5rem 0; color: #4338CA;">📁 Supported Formats</h4>
        <p style="margin: 0; color: #4B5563;">
            <strong>CSV</strong> • <strong>Excel (.xlsx)</strong> • <strong>JSON</strong> • <strong>Parquet</strong>
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Data type selector
    data_type = st.selectbox(
        "Select Data Type",
        options=['models', 'metrics', 'predictions', 'reference_data', 'alerts', 'raw_features'],
        format_func=lambda x: {
            'models': '📊 Model Registry',
            'metrics': '📈 Performance Metrics',
            'predictions': '🎯 Prediction Logs',
            'reference_data': '📋 Reference Data (for drift)',
            'alerts': '🚨 Custom Alerts',
            'raw_features': '🔢 Raw Feature Data'
        }.get(x, x)
    )
    
    # Show schema information
    if data_type in SCHEMAS:
        schema = SCHEMAS[data_type]
        
        with st.expander("📋 View Expected Format", expanded=False):
            st.markdown(f"**Description:** {schema.description}")
            
            st.markdown("**Required Columns:**")
            if schema.required_columns:
                for col in schema.required_columns:
                    col_type = schema.column_types.get(col, 'any')
                    st.markdown(f"- `{col}` ({col_type})")
            else:
                st.markdown("- *Any columns accepted*")
            
            st.markdown("**Optional Columns:**")
            for col in schema.optional_columns[:5]:
                col_type = schema.column_types.get(col, 'any')
                st.markdown(f"- `{col}` ({col_type})")
            if len(schema.optional_columns) > 5:
                st.markdown(f"- *...and {len(schema.optional_columns) - 5} more*")
            
            st.markdown("**Example Data:**")
            example_df = pd.DataFrame(schema.example_data)
            st.dataframe(example_df, use_container_width=True)
            
            # Download template button
            csv_template = example_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Template CSV",
                data=csv_template,
                file_name=f"{data_type}_template.csv",
                mime="text/csv"
            )
    
    # Model selector for reference/features data
    model_id = None
    if data_type in ['reference_data', 'raw_features']:
        models = data_store.get_models()
        model_options = list(models.keys()) + ['new_model']
        model_id = st.selectbox("Select Model", options=model_options)
        
        if model_id == 'new_model':
            model_id = st.text_input("Enter new model ID")
    
    # File uploader
    uploaded_file = st.file_uploader(
        "Choose a file",
        type=['csv', 'xlsx', 'xls', 'json', 'parquet'],
        key=f"uploader_{data_type}"
    )
    
    if uploaded_file:
        # Read file
        df, error = read_uploaded_file(uploaded_file)
        
        if error:
            st.error(f"❌ {error}")
            return
        
        # Show preview
        st.markdown("#### 👀 Data Preview")
        st.dataframe(df.head(10), use_container_width=True)
        st.markdown(f"*{len(df)} rows × {len(df.columns)} columns*")
        
        # Validate
        is_valid, errors, warnings = validate_dataframe(df, data_type)
        
        if errors:
            for err in errors:
                st.error(f"❌ {err}")
        
        if warnings:
            for warn in warnings:
                st.warning(f"⚠️ {warn}")
        
        # Column mapping for flexibility
        if data_type != 'raw_features':
            with st.expander("🔧 Column Mapping (optional)"):
                st.markdown("Map your columns to expected names if they differ:")
                
                schema = SCHEMAS.get(data_type)
                if schema:
                    col_mapping = {}
                    
                    for expected_col in schema.required_columns + schema.optional_columns[:5]:
                        if expected_col not in df.columns:
                            mapped_col = st.selectbox(
                                f"Map to '{expected_col}'",
                                options=['-- skip --'] + list(df.columns),
                                key=f"map_{data_type}_{expected_col}"
                            )
                            if mapped_col != '-- skip --':
                                col_mapping[mapped_col] = expected_col
                    
                    if col_mapping:
                        df = df.rename(columns=col_mapping)
                        st.success(f"Mapped columns: {col_mapping}")
        
        # Upload button
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("✅ Upload Data", type="primary", use_container_width=True):
                # Preprocess
                df = preprocess_dataframe(df, data_type)
                
                # Store data
                try:
                    if data_type == 'models':
                        data_store.add_models(df)
                    elif data_type == 'metrics':
                        data_store.add_metrics(df)
                    elif data_type == 'predictions':
                        data_store.add_predictions(df)
                    elif data_type == 'reference_data':
                        if model_id:
                            data_store.add_reference_data(model_id, df)
                        else:
                            st.error("Please select a model")
                            return
                    elif data_type == 'alerts':
                        data_store.add_alerts(df)
                    elif data_type == 'raw_features':
                        if model_id:
                            data_store.add_raw_features(model_id, df)
                        else:
                            st.error("Please select a model")
                            return
                    
                    st.success(f"✅ Successfully uploaded {len(df)} records!")
                    st.balloons()
                    
                except Exception as e:
                    st.error(f"❌ Error uploading data: {str(e)}")
        
        with col2:
            if st.button("🗑️ Clear", use_container_width=True):
                st.rerun()


def render_upload_status(data_store: UploadedDataStore):
    """Render upload status summary"""
    
    st.markdown("### 📊 Data Status")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        model_count = len(data_store.models) if data_store.models else len(data_store._get_demo_models())
        source = "uploaded" if data_store.models else "demo"
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-card-value">{model_count}</div>
            <div class="stat-card-label">📊 Models ({source})</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        metrics_count = len(data_store.metrics) if not data_store.metrics.empty else 0
        source = "uploaded" if metrics_count > 0 else "demo"
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-card-value">{metrics_count:,}</div>
            <div class="stat-card-label">📈 Metrics ({source})</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        pred_count = len(data_store.predictions) if not data_store.predictions.empty else 0
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-card-value">{pred_count:,}</div>
            <div class="stat-card-label">🎯 Predictions</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        ref_count = len(data_store.reference_data)
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-card-value">{ref_count}</div>
            <div class="stat-card-label">📋 Reference Sets</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Upload history
    if data_store.upload_history:
        with st.expander("📜 Upload History"):
            for upload in reversed(data_store.upload_history[-10:]):
                st.markdown(f"• **{upload['data_type']}**: {upload['records']} records @ {upload['timestamp'].strftime('%H:%M:%S')}")
    
    # Clear all button
    if st.button("🗑️ Clear All Uploaded Data"):
        data_store.clear_all()
        st.success("All data cleared!")
        st.rerun()


def render_sample_data_generator():
    """Render sample data generator for testing"""
    
    st.markdown("### 🎲 Generate Sample Data")
    
    st.markdown("""
    Don't have data ready? Generate sample data to test the platform!
    """)
    
    col1, col2 = st.columns(2)
    
    with col1:
        n_models = st.slider("Number of models", 1, 10, 3)
        n_days = st.slider("Days of metrics", 1, 30, 7)
    
    with col2:
        n_predictions = st.slider("Predictions per model", 100, 10000, 1000)
        include_anomalies = st.checkbox("Include anomalies", value=True)
    
    if st.button("🎲 Generate Sample Data", type="primary"):
        # Generate models
        models_data = []
        for i in range(n_models):
            models_data.append({
                'model_id': f'model_{i+1:03d}',
                'name': f'Sample Model {i+1}',
                'type': np.random.choice(['Classification', 'Regression']),
                'framework': np.random.choice(['XGBoost', 'LightGBM', 'PyTorch', 'TensorFlow']),
                'version': f'v{np.random.randint(1, 5)}.{np.random.randint(0, 10)}.{np.random.randint(0, 10)}',
                'status': np.random.choice(['healthy', 'healthy', 'healthy', 'warning', 'critical']),
                'predictions_today': np.random.randint(1000, 50000),
                'avg_latency_ms': np.random.uniform(10, 100)
            })
        
        models_df = pd.DataFrame(models_data)
        
        # Generate metrics
        metrics_data = []
        for model in models_data:
            timestamps = pd.date_range(end=datetime.now(), periods=n_days * 24 * 6, freq='10min')
            for ts in timestamps:
                metrics_data.append({
                    'model_id': model['model_id'],
                    'timestamp': ts,
                    'metric_name': 'mae',
                    'metric_value': 0.05 + np.random.normal(0, 0.01)
                })
                metrics_data.append({
                    'model_id': model['model_id'],
                    'timestamp': ts,
                    'metric_name': 'latency_ms',
                    'metric_value': 20 + np.random.exponential(15)
                })
        
        metrics_df = pd.DataFrame(metrics_data)
        
        # Generate predictions
        predictions_data = []
        features = ['age', 'income', 'tenure', 'usage', 'support_tickets']
        
        for model in models_data:
            for i in range(n_predictions):
                row = {
                    'model_id': model['model_id'],
                    'timestamp': datetime.now() - timedelta(minutes=i),
                    'prediction': np.random.random(),
                    'actual': np.random.random() if np.random.random() > 0.3 else None,
                    'latency_ms': np.random.exponential(20)
                }
                
                for f in features:
                    row[f] = np.random.normal(50, 20)
                
                if include_anomalies and np.random.random() < 0.02:
                    row['is_anomaly'] = True
                    row['anomaly_score'] = np.random.uniform(0.8, 1.0)
                
                predictions_data.append(row)
        
        predictions_df = pd.DataFrame(predictions_data)
        
        # Create download links
        st.success("✅ Sample data generated!")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.download_button(
                "📥 Download Models CSV",
                models_df.to_csv(index=False),
                "sample_models.csv",
                "text/csv"
            )
        
        with col2:
            st.download_button(
                "📥 Download Metrics CSV",
                metrics_df.to_csv(index=False),
                "sample_metrics.csv",
                "text/csv"
            )
        
        with col3:
            st.download_button(
                "📥 Download Predictions CSV",
                predictions_df.to_csv(index=False),
                "sample_predictions.csv",
                "text/csv"
            )


# =============================================================================
# INITIALIZATION FUNCTION
# =============================================================================

def get_data_store() -> UploadedDataStore:
    """Get or create the data store in session state"""
    if 'data_store' not in st.session_state:
        st.session_state.data_store = UploadedDataStore()
    return st.session_state.data_store
