-- ML Model Monitor Pro - Database Schema
-- =============================================================================
-- Run this SQL to set up your monitoring database
-- Supports: PostgreSQL, MySQL (with minor modifications)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- MODELS TABLE: Registry of all monitored models
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS models (
    model_id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,  -- 'Classification', 'Regression'
    framework VARCHAR(100),      -- 'XGBoost', 'PyTorch', 'TensorFlow', etc.
    version VARCHAR(50),
    description TEXT,
    deployed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'healthy',  -- 'healthy', 'warning', 'critical'
    is_active BOOLEAN DEFAULT TRUE,
    config JSONB,  -- Model-specific configuration
    
    -- Cached metrics (updated periodically)
    predictions_today INTEGER DEFAULT 0,
    predictions_total BIGINT DEFAULT 0,
    avg_latency_ms FLOAT,
    accuracy FLOAT,
    mae FLOAT,
    f1_score FLOAT,
    data_size_mb FLOAT
);

CREATE INDEX idx_models_status ON models(status);
CREATE INDEX idx_models_active ON models(is_active);

-- -----------------------------------------------------------------------------
-- METRICS TABLE: Time-series performance metrics
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS metrics (
    id BIGSERIAL PRIMARY KEY,
    model_id VARCHAR(100) NOT NULL REFERENCES models(model_id),
    metric_name VARCHAR(100) NOT NULL,  -- 'mae', 'rmse', 'accuracy', 'latency_ms', etc.
    metric_value FLOAT NOT NULL,
    batch_size INTEGER DEFAULT 1,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB
);

CREATE INDEX idx_metrics_model_time ON metrics(model_id, timestamp DESC);
CREATE INDEX idx_metrics_name ON metrics(metric_name);

-- Partition by time for large-scale deployments (PostgreSQL 10+)
-- CREATE TABLE metrics (
--     ...
-- ) PARTITION BY RANGE (timestamp);

-- -----------------------------------------------------------------------------
-- PREDICTIONS TABLE: Individual prediction logs
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS predictions (
    prediction_id VARCHAR(100) PRIMARY KEY DEFAULT gen_random_uuid()::text,
    model_id VARCHAR(100) NOT NULL REFERENCES models(model_id),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    features JSONB NOT NULL,           -- Input features
    prediction FLOAT NOT NULL,         -- Model output
    actual FLOAT,                      -- Ground truth (when available)
    probability FLOAT,                 -- For classification
    latency_ms FLOAT,
    is_anomaly BOOLEAN DEFAULT FALSE,
    anomaly_score FLOAT,
    metadata JSONB
);

CREATE INDEX idx_predictions_model_time ON predictions(model_id, timestamp DESC);
CREATE INDEX idx_predictions_anomaly ON predictions(model_id, is_anomaly) WHERE is_anomaly = TRUE;

-- -----------------------------------------------------------------------------
-- REFERENCE_DATA TABLE: Training data distribution statistics
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reference_data (
    id SERIAL PRIMARY KEY,
    model_id VARCHAR(100) NOT NULL REFERENCES models(model_id),
    feature_name VARCHAR(100) NOT NULL,
    mean_value FLOAT,
    std_value FLOAT,
    min_value FLOAT,
    max_value FLOAT,
    percentile_25 FLOAT,
    percentile_50 FLOAT,
    percentile_75 FLOAT,
    percentile_95 FLOAT,
    percentile_99 FLOAT,
    histogram JSONB,  -- Binned distribution for PSI calculation
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(model_id, feature_name)
);

CREATE INDEX idx_reference_model ON reference_data(model_id);

-- -----------------------------------------------------------------------------
-- DRIFT_HISTORY TABLE: Drift detection results over time
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS drift_history (
    id BIGSERIAL PRIMARY KEY,
    model_id VARCHAR(100) NOT NULL REFERENCES models(model_id),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    overall_score FLOAT NOT NULL,
    drift_detected BOOLEAN NOT NULL,
    n_features_drifted INTEGER,
    feature_scores JSONB,  -- Per-feature PSI, KS scores
    metadata JSONB
);

CREATE INDEX idx_drift_model_time ON drift_history(model_id, timestamp DESC);

-- -----------------------------------------------------------------------------
-- ALERTS TABLE: Alert history and management
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alerts (
    alert_id VARCHAR(100) PRIMARY KEY DEFAULT gen_random_uuid()::text,
    model_id VARCHAR(100) REFERENCES models(model_id),
    severity VARCHAR(20) NOT NULL,  -- 'info', 'low', 'medium', 'high', 'critical'
    category VARCHAR(50) NOT NULL,  -- 'drift', 'performance', 'latency', 'error', etc.
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active',  -- 'active', 'acknowledged', 'resolved'
    acknowledged_by VARCHAR(100),
    acknowledged_at TIMESTAMP,
    resolved_at TIMESTAMP,
    resolution_notes TEXT,
    recommendations JSONB,
    details JSONB,
    tags TEXT[]
);

CREATE INDEX idx_alerts_model ON alerts(model_id);
CREATE INDEX idx_alerts_status ON alerts(status);
CREATE INDEX idx_alerts_severity ON alerts(severity);
CREATE INDEX idx_alerts_time ON alerts(timestamp DESC);

-- -----------------------------------------------------------------------------
-- ALERT_RULES TABLE: Configurable alerting rules
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alert_rules (
    rule_id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    model_id VARCHAR(100) REFERENCES models(model_id),  -- NULL = applies to all
    category VARCHAR(50) NOT NULL,
    metric_name VARCHAR(100),
    condition VARCHAR(20) NOT NULL,  -- 'gt', 'lt', 'gte', 'lte', 'eq'
    threshold FLOAT NOT NULL,
    severity VARCHAR(20) NOT NULL,
    cooldown_minutes INTEGER DEFAULT 30,
    is_enabled BOOLEAN DEFAULT TRUE,
    notification_channels TEXT[],  -- ['slack', 'email', 'webhook']
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- -----------------------------------------------------------------------------
-- USERS TABLE: For multi-user deployments (optional)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(100) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'viewer',  -- 'admin', 'editor', 'viewer'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

-- -----------------------------------------------------------------------------
-- AUDIT_LOG TABLE: Track all changes (optional)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_id VARCHAR(100),
    action VARCHAR(50) NOT NULL,  -- 'create', 'update', 'delete', 'acknowledge', etc.
    entity_type VARCHAR(50) NOT NULL,  -- 'model', 'alert', 'rule', etc.
    entity_id VARCHAR(100),
    details JSONB
);

CREATE INDEX idx_audit_time ON audit_log(timestamp DESC);

-- -----------------------------------------------------------------------------
-- HELPER FUNCTIONS
-- -----------------------------------------------------------------------------

-- Function to update model status based on recent alerts
CREATE OR REPLACE FUNCTION update_model_status()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE models
    SET status = (
        SELECT CASE
            WHEN EXISTS (
                SELECT 1 FROM alerts 
                WHERE model_id = NEW.model_id 
                AND status = 'active' 
                AND severity = 'critical'
            ) THEN 'critical'
            WHEN EXISTS (
                SELECT 1 FROM alerts 
                WHERE model_id = NEW.model_id 
                AND status = 'active' 
                AND severity IN ('high', 'medium')
            ) THEN 'warning'
            ELSE 'healthy'
        END
    ),
    updated_at = CURRENT_TIMESTAMP
    WHERE model_id = NEW.model_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_model_status
AFTER INSERT OR UPDATE ON alerts
FOR EACH ROW
EXECUTE FUNCTION update_model_status();

-- Function to update daily prediction counts
CREATE OR REPLACE FUNCTION update_prediction_counts()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE models
    SET 
        predictions_today = (
            SELECT COUNT(*) FROM predictions 
            WHERE model_id = NEW.model_id 
            AND timestamp >= CURRENT_DATE
        ),
        predictions_total = predictions_total + 1,
        updated_at = CURRENT_TIMESTAMP
    WHERE model_id = NEW.model_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_prediction_counts
AFTER INSERT ON predictions
FOR EACH ROW
EXECUTE FUNCTION update_prediction_counts();

-- -----------------------------------------------------------------------------
-- SAMPLE DATA (for testing)
-- -----------------------------------------------------------------------------

-- Insert sample models
INSERT INTO models (model_id, name, type, framework, version, status) VALUES
('model_001', 'Customer Churn Predictor', 'Classification', 'XGBoost', 'v2.3.1', 'healthy'),
('model_002', 'Revenue Forecaster', 'Regression', 'LightGBM', 'v1.8.0', 'warning'),
('model_003', 'Fraud Detection', 'Classification', 'PyTorch', 'v3.1.2', 'healthy'),
('model_004', 'Demand Predictor', 'Regression', 'TensorFlow', 'v2.0.0', 'critical')
ON CONFLICT (model_id) DO NOTHING;

-- Insert sample alert rules
INSERT INTO alert_rules (rule_id, name, category, metric_name, condition, threshold, severity) VALUES
('rule_001', 'High Latency', 'latency', 'latency_p95', 'gt', 50, 'medium'),
('rule_002', 'Critical Latency', 'latency', 'latency_p95', 'gt', 100, 'critical'),
('rule_003', 'High Error Rate', 'performance', 'error_rate', 'gt', 0.01, 'high'),
('rule_004', 'Data Drift Warning', 'drift', 'psi_max', 'gt', 0.1, 'medium'),
('rule_005', 'Data Drift Critical', 'drift', 'psi_max', 'gt', 0.2, 'critical')
ON CONFLICT (rule_id) DO NOTHING;

-- -----------------------------------------------------------------------------
-- VIEWS FOR COMMON QUERIES
-- -----------------------------------------------------------------------------

-- Latest metrics per model
CREATE OR REPLACE VIEW latest_metrics AS
SELECT DISTINCT ON (model_id, metric_name)
    model_id,
    metric_name,
    metric_value,
    timestamp
FROM metrics
ORDER BY model_id, metric_name, timestamp DESC;

-- Active alerts summary
CREATE OR REPLACE VIEW active_alerts_summary AS
SELECT 
    model_id,
    COUNT(*) as alert_count,
    COUNT(*) FILTER (WHERE severity = 'critical') as critical_count,
    COUNT(*) FILTER (WHERE severity = 'high') as high_count,
    MAX(timestamp) as latest_alert
FROM alerts
WHERE status = 'active'
GROUP BY model_id;

-- Model health overview
CREATE OR REPLACE VIEW model_health_overview AS
SELECT 
    m.model_id,
    m.name,
    m.status,
    m.predictions_today,
    m.avg_latency_ms,
    COALESCE(a.alert_count, 0) as active_alerts,
    COALESCE(a.critical_count, 0) as critical_alerts
FROM models m
LEFT JOIN active_alerts_summary a ON m.model_id = a.model_id
WHERE m.is_active = TRUE;

-- -----------------------------------------------------------------------------
-- CLEANUP JOBS (run periodically)
-- -----------------------------------------------------------------------------

-- Delete old metrics (keep last 30 days)
-- DELETE FROM metrics WHERE timestamp < NOW() - INTERVAL '30 days';

-- Delete old predictions (keep last 7 days)
-- DELETE FROM predictions WHERE timestamp < NOW() - INTERVAL '7 days';

-- Archive resolved alerts older than 90 days
-- DELETE FROM alerts WHERE status = 'resolved' AND resolved_at < NOW() - INTERVAL '90 days';
